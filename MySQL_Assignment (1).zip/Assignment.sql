			                         /*Selecting the database Assignment*/

USE Assignment;

										/*Change text to Date*/

UPDATE bajajauto SET `Date` = str_to_date(`Date`, '%e-%M-%Y');
UPDATE eichermotors SET `Date` = str_to_date(`Date`, '%e-%M-%Y');
UPDATE heromotocorp SET `Date` = str_to_date(`Date`, '%e-%M-%Y');
UPDATE infosys SET `Date` = str_to_date(`Date`, '%e-%M-%Y');
UPDATE tcs SET `Date` = str_to_date(`Date`, '%e-%M-%Y');
UPDATE tvs SET `Date` = str_to_date(`Date`, '%e-%M-%Y');

					/*Creating table bajaj1 containing the date, close price, 20 Day MA and 50 Day MA*/

CREATE TABLE bajaj1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`bajajauto`;

                    /*Creating table eicher1 containing the date, close price, 20 Day MA and 50 Day MA*/

create table eicher1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`eichermotors`;

			       /*Creating table hero1 containing the date, close price, 20 Day MA and 50 Day MA*/

create table hero1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`heromotocorp`;

                 /*Creating table infosys1 containing the date, close price, 20 Day MA and 50 Day MA*/

create table infosys1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`infosys`;

                /*Creating table tcs1 containing the date, close price, 20 Day MA and 50 Day MA*/

create table tcs1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`tcs`;

                   /*Creating table tvsmotors1 containing the date, close price, 20 Day MA and 50 Day MA*/

create table tvsmotors1 as
SELECT Date, (`Close Price`,2) as `Close Price`, 
AVG(`Close Price`) OVER(order by `Date` ROWS 19 PRECEDING and current row)AS `20 Day MA`,
AVG(`Close Price`) OVER(order by `Date` ROWS 49 PRECEDING and current row) AS `50 Day MA`
FROM Assignment.`tvsmotors`;

			                      /*Creating a Master table*/

create table master_table as 

select b.date as `Date`, 
b.`Close Price` as `Bajaj`, 
tc.`Close Price` as `TCS`,
tv.`Close Price` as `TVSMOTORS`,
i.`Close Price` as `Infosys`,
e.`Close Price` as `Eicher`,
h.`Close Price` as `Hero`

from bajaj1 b 

INNER JOIN tcs1 tc on tc.date = b.date
INNER JOIN tvsmotors1 tv on tv.date = tc.date
INNER JOIN infosys1 i on i.date = tv.date
INNER JOIN eicher1 e on e.date = i.date
INNER JOIN hero1 h on h.date = e.date;

/*Creating Table bajaj2 with details from bajaj1 and including the signal(buy/sell/hold)*/

create table bajaj2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG (`20 Day MA`)  over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG (`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.bajaj1;

/*Creating Table eicher2 with details from eicher1 and including the signal(buy/sell/hold)*/

create table eicher2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.eicher1;

/*Creating Table hero2 with details from hero1 and including the signal(buy/sell/hold)*/

create table hero2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.hero1;

/*Creating Table infosys2 with details from infosys1 and including the signal(buy/sell/hold)*/

create table infosys2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.infosys1;

/*Creating Table tcs2 with details from tcs1 and including the signal(buy/sell/hold)*/

create table tcs2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.tcs1;

/*Creating Table tvsmotors2 with details from tvsmotors1 and including the signal(buy/sell/hold)*/

create table tvsmotors2 as 
SELECT `Date`, `Close Price`,
(case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`)  over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end) as `Signal`
FROM Assignment.tvsmotors1;

                                /*Creating the required User defined function*/

DROP function IF EXISTS Assignment.signal_1;


delimiter $$
create function signal_1 (given_date varchar(10))
returns varchar(50) deterministic
begin
declare sig_value varchar(5);
set sig_value = (select 'Signal' from bajaj2 where Date = STR_TO_DATE(given_date, "%Y-%m-%d"));
return sig_value;
end$$
delimiter ;
select signal_1('2016-03-16') as `signal`;

